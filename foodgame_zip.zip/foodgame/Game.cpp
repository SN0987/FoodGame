#include <iostream>
#include <allegro5/allegro5.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_primitives.h>
#include "includes/Game.hpp"
#include <vector>
#include "includes/Background.hpp"
#include "includes/StringFont.hpp"
#include "includes/Snow.hpp"
#include "includes/Player.hpp"
#include "includes/Pepper.hpp"
#include "includes/BellPepper.hpp"
#include "includes/Bullets.hpp"
#include "includes/Random.hpp"

void Game::registerTimers() {
    for(int i = 0;i<timers.size();i++) {
        al_register_event_source(queue,al_get_timer_event_source(timers[i]));
        al_start_timer(timers[i]);
    }
}

void Game::unregisterTimers() {
    for(int i = 0;i<timers.size();i++) {
        al_unregister_event_source(queue,al_get_timer_event_source(timers[i]));
        al_stop_timer(timers[i]);
    }
}

void Game::destroyTimers() {
    for(int i = 0;i<timers.size();i++) {
        al_destroy_timer(timers[i]);
        timers[i] = nullptr;

    }
}


void Game::destroyFonts() {
    for(int i = 0;i<fonts.size();i++) {
        al_destroy_font(fonts[i]);
        fonts[i] = nullptr;

    }
}


void Game::destroyImages() {
    for(int i = 0;i<bitmaps.size();i++) {
        al_destroy_bitmap(bitmaps[i]);
        bitmaps[i] = nullptr;
    }
}

void Game::init() {
    if(!al_init()) {
        printf("ERROR ALLEGRO5 NOT INITIALIZED\n");
    } 

    if(!al_init_image_addon()) {
        printf("ERROR IMAGE NOT INTIALIZED\n");
    } 


    if(!al_init_font_addon()) {
        printf("ERROR FONT NOT INITIALIZED\n");
    } 


    if(!al_init_ttf_addon()) {
        printf("ERROR TTF NOT INITIALIZED\n");
    } 

    if(!al_init_primitives_addon()) {
        printf("ERROR PRIMITIVES NOT INTIALIZED\n");
    }

    
    if(!al_install_keyboard()) {
        printf("ERROR KEYBOARD DRIVER FAILED\n");
    } 

    if(!al_install_mouse()) {
        printf("ERROR MOUSE DRIVER FAILED\n");
    }
}



void Game::load() {
    init();

    display = nullptr;
    fpsTimer = nullptr;
    queue = nullptr;
    clickTimerOne = nullptr;
    clickTimerTwo = nullptr;
    reverseTimerOne = nullptr;
    reverseTimerTwo = nullptr;

    display = al_create_display(this->width,this->height);

    queue = al_create_event_queue();

    fpsTimer = al_create_timer(1.0/this->fps);

    clickTimerOne = al_create_timer(2);
    clickTimerTwo = al_create_timer(3);
    reverseTimerOne = al_create_timer(15);
    reverseTimerTwo = al_create_timer(15);


    timers.push_back(fpsTimer);
    timers.push_back(clickTimerOne);
    timers.push_back(clickTimerTwo);
  


    al_register_event_source(queue,al_get_display_event_source(display));
    al_register_event_source(queue,al_get_keyboard_event_source());
    al_register_event_source(queue,al_get_mouse_event_source());
    al_register_event_source(queue,al_get_timer_event_source(reverseTimerTwo));
    al_register_event_source(queue,al_get_timer_event_source(reverseTimerOne));
    //vars
    isDisplay = false;
    reverse = false;

    //end
    //classes
    bg = new Background(bitmaps);
    titleText = new StringFont(135,0,100,fonts);
    titleText->setColor(al_map_rgb(0,0,0));
    titleText->setText("Food and Cups");

    clickText = new StringFont(245,350,60,fonts);
    clickText->setColor(al_map_rgb(0,0,0));
    clickText->setText("Click To Play");

    snowRed = new Snow(40,3);
    snowRed->setColor(al_map_rgb(200,0,0));

    snowGreen = new Snow(40,3);
    snowGreen->setColor(al_map_rgb(0,200,0));

    player = new Player(this->width/2-80,512-80,bitmaps);
    pepper = new Pepper(bitmaps);
    bPepper = new BellPepper(bitmaps);
    bullets = new Bullets(-6,al_map_rgb(0,130,0));
    gameTime = 0;
    seconds = 0;
    spawnBellTime = 0;
    spawnPepperTime = 0;

    timeText = new StringFont(0,0,50,fonts);
    timeText->setColor(al_map_rgb(0,0,0));
    timeText->setText("Time " + std::to_string(gameTime));

    modeText = new StringFont(205,160,140,fonts);
    modeText->setColor(al_map_rgb(0,0,0));
    modeText->setText("Regular");
    
    foodOne = new Food(bitmaps,3);
    foodTwo = new Food(bitmaps,2);
    foodThree = new Food(bitmaps,4);
    //end
    registerTimers();

}

void Game::update() {
    snowRed->update(reverse);
    snowGreen->update(reverse);
    if(this->state == "menu") {

    }

    if(this->state == "game") {
        seconds++;
        if(seconds >= 60) {
            seconds = 0;
            gameTime++;
            timeText->setText("Time " + std::to_string(gameTime));
            spawnBellTime++;
            if(spawnBellTime >= 15) {
                spawnBellTime = 0;
                if(bPepper->bellpeppers < 3) {
                    bPepper->bellpeppers++;
                }
            }

            spawnPepperTime++;
            if(spawnPepperTime >= 20) {
                spawnPepperTime = 0;
                if(pepper->peppers < 3) {
                    pepper->peppers++;
                }
            } 
        }
        player->update(reverse,&ks);
        bullets->update();
        foodOne->update(*bullets,reverse);
        foodTwo->update(*bullets,reverse);
        foodThree->update(*bullets,reverse);

        if(player->getRect()->collide(*foodOne->getRect()) || player->getRect()->collide(*foodTwo->getRect()) || player->getRect()->collide(*foodThree->getRect())) {
            if(player->reverseTime >= 60) {
                resetGame();
                this->state = "menu";
            }
        }
    }
}

void Game::render() {
    bg->render(reverse);
    snowRed->render();
    snowGreen->render();
    if(this->state == "menu") {
        titleText->render();
        clickText->render();
    }

    if(this->state == "game") {
        player->render();
        pepper->render();
        bPepper->render();
        bullets->render();

        timeText->render();
        modeText->render();
        foodOne->render(reverse);
        foodTwo->render(reverse);
        foodThree->render(reverse);
    }
}


void Game::loop() {

    while(this->state != "quit") {
        ALLEGRO_EVENT event;
        al_wait_for_event(queue,&event);
        al_get_keyboard_state(&ks);
        al_get_mouse_state(&ms);

        if(event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
            this->state = "quit";
        }

        if(event.type == ALLEGRO_EVENT_KEY_DOWN) {
            if(event.keyboard.keycode == ALLEGRO_KEY_SPACE) {
                if(this->state == "menu") {
                    resetMenu();
                    this->state = "game";
                }
            }

            if(event.keyboard.keycode == ALLEGRO_KEY_BACKSPACE) {
                if(this->state == "game") {
                    resetGame();
                    this->state = "menu";
                }
            }

            if(event.keyboard.keycode == ALLEGRO_KEY_P) {
                if(this->state == "game") {
                    pepper->update(*player);
                }
            }

            if(event.keyboard.keycode == ALLEGRO_KEY_B) {
                if(this->state == "game") {
                    bPepper->update(*bullets,*player);
                }
            }

        }

        if(event.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN) {
            if(event.mouse.button == 1) {
                if(this->state == "menu") {
                    resetMenu();
                    this->state = "game";
                }
            } 
        }

        

        if(event.type == ALLEGRO_EVENT_TIMER) {
            if(event.timer.source == fpsTimer) {
                isDisplay = true;

            }

            if(event.timer.source == clickTimerOne) {
                clickText->setText("");
            }
            
            if(event.timer.source == clickTimerTwo) {
                clickText->setText("Click To Play");

            }

            if(event.timer.source == reverseTimerOne) {
                reverse = true;
                player->setPosition(player->getRect()->x,0);
                bullets->setColor(al_map_rgb(200,0,0));
                bullets->setSpeedY(6);
                al_stop_timer(reverseTimerOne);
                al_start_timer(reverseTimerTwo);
                modeText->setText("Reverse");
                foodOne->setFallSpeed((foodOne->getFallSpeed() + 1)*-1);
                foodTwo->setFallSpeed((foodTwo->getFallSpeed() + 1)*-1);
                foodThree->setFallSpeed((foodThree->getFallSpeed() + 1)*-1);
                player->reverseTime = 0;
            }

            if(event.timer.source == reverseTimerTwo) {
                reverse = false;
                player->setPosition(player->getRect()->x,512-80);
                bullets->setColor(al_map_rgb(0,130,0));
                bullets->setSpeedY(-6);
                al_start_timer(reverseTimerOne);
                al_stop_timer(reverseTimerTwo);
                modeText->setText("Regular");
                foodOne->setFallSpeed((foodOne->getFallSpeed() + -1)*-1);
                foodTwo->setFallSpeed((foodTwo->getFallSpeed() + -1)*-1);
                foodThree->setFallSpeed((foodThree->getFallSpeed() + -1)*-1);
                player->reverseTime = 0;
            }

            
        }

        if(isDisplay && al_is_event_queue_empty(queue)) {
            isDisplay = false;

            update();
            
            al_clear_to_color(al_map_rgb(255,0,0));
            render();
            al_flip_display();
        }


    }

    destroy();
}

void Game::destroy() {
    unregisterTimers();
    al_unregister_event_source(queue,al_get_display_event_source(display));
    al_unregister_event_source(queue,al_get_keyboard_event_source());
    al_unregister_event_source(queue,al_get_mouse_event_source());
    al_unregister_event_source(queue,al_get_timer_event_source(reverseTimerTwo));
    al_unregister_event_source(queue,al_get_timer_event_source(reverseTimerOne));

    al_uninstall_keyboard();
    al_uninstall_mouse();

    al_destroy_display(display);
    al_destroy_event_queue(queue);
    al_destroy_timer(reverseTimerTwo);
    al_destroy_timer(reverseTimerOne);

    destroyTimers();
    destroyImages();
    destroyFonts();

    display = nullptr;
    queue = nullptr;
    reverseTimerTwo = nullptr;
    reverseTimerOne = nullptr;

}


void Game::resetGame() {
    reverse = false;
    al_start_timer(clickTimerOne);
    al_start_timer(clickTimerTwo);
    player->setPosition(this->width/2-80,512-80);
    al_stop_timer(reverseTimerOne);
    al_stop_timer(reverseTimerTwo);
    pepper->peppers = 3;
    bPepper->bellpeppers = 3;
    bullets->setColor(al_map_rgb(0,130,0));
    bullets->setSpeedY(-6);

    gameTime = 0;
    spawnBellTime = 0;
    spawnPepperTime = 0;
    seconds = 0;
    timeText->setText("Time " + std::to_string(gameTime));

    foodOne->setFallSpeed(3);
    foodTwo->setFallSpeed(2);
    foodThree->setFallSpeed(4);
    foodOne->getRect()->setPosition(Random::getRange(0,800),0);
    foodTwo->getRect()->setPosition(Random::getRange(0,800),0);
    foodThree->getRect()->setPosition(Random::getRange(0,800),0);

    player->setPosition(this->width/2-80,512-80);
    modeText->setText("Regular");
}   

void Game::resetMenu() {
    al_stop_timer(clickTimerOne);
    al_stop_timer(clickTimerTwo);
    al_start_timer(reverseTimerOne);
    reverse = false;
}