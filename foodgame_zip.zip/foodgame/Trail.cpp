#include <allegro5/allegro5.h>
#include <allegro5/allegro_primitives.h>
#include <iostream>
#include "includes/Rectangle.hpp"
#include <vector>
#include "includes/Trail.hpp"





void Trail::add(int x,int y) {
    rectlist.push_back(Rectangle(x,y,w,h));

}


void Trail::update() {
    for(int i = 0;i<rectlist.size();i++) {
        rectlist[i].x += velX;
        rectlist[i].y += velY;

        time++;
        if(time >= 2) {
            time = 0;
            if(rectlist[i].w <= 1 || rectlist[i].h <= 1) {
                rectlist.erase(rectlist.begin() + i);
            } else {
                rectlist[i].w -= 1;
                rectlist[i].h -= 1;
            }
        }
    }
}


void Trail::setColor(ALLEGRO_COLOR color) {
    this->color = color;
}

void Trail::render() {
    for(int i = 0;i<rectlist.size();i++) {
        al_draw_filled_rectangle(rectlist[i].x,rectlist[i].y,rectlist[i].x + rectlist[i].w,rectlist[i].y + rectlist[i].w,this->color);
    }
}

void Trail::setVelY(int velY) {
    this->velY = velY;
}

void Trail::setVelX(int velX) {
    this->velX = velX;
}