#include <iostream>
#include <cstdlib>
#include "includes/Random.hpp"
#include <random>

int Random::getRange(int min,int max) {
    return min + rand() % (max + 1 - min);
}