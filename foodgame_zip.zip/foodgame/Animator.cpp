#include <allegro5/allegro5.h>
#include <allegro5/allegro_image.h>
#include <iostream>

#include "includes/Animator.hpp"





void Animator::animate(int fps,int aOfFrames,ALLEGRO_BITMAP* bitmap,float x,float y,float width,float height) {
    time++;

    if(time >= fps) {
        time = 0;
        if(frames >= aOfFrames ) {
            frames = 0;
        } else {
            frames++;
        }
    }    


    al_draw_scaled_bitmap(bitmap,frames*32,0,32,32,x,y,width,height,0);
}