#include <iostream>
#include "includes/Rectangle.hpp"
#include <cmath>



void Rectangle::setDimensions(float w,float h) {
    this->w = w;
    this->h = h;
}


void Rectangle::setPosition(float x,float y) {
    this->x = x;
    this->y = y;

}

bool Rectangle::collide(Rectangle rect) {
    bool col = false;

    if(x < rect.x + rect.w && x + w > rect.x && y < rect.y + rect.h && y + h > rect.y) {
        col = true;
    } else {
        col = false;
    }

    return col;
}

bool Rectangle::collidePoint(float& cx,float& cy) {
    bool col = false;

    if(abs(cx - (x + w/2)) < w/2 && abs(cy - (y+h/2)) < h/2) {
        col = true;
    } else {
        col = false;
    }

    return col;
}