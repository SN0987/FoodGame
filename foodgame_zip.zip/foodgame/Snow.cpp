#include <allegro5/allegro5.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include <iostream>
#include <vector>
#include "includes/Rectangle.hpp"
#include "includes/Random.hpp"
#include "includes/Snow.hpp"


void Snow::setColor(ALLEGRO_COLOR color) {
    this->color = color;

}


void Snow::update(bool& reverse) {
    
    for(int i = 0;i<rects.size();i++) {
        if(reverse) {
            rects[i].y -= speed;
            if(rects[i].y < 0) {
                int size = Random::getRange(2,5);
                rects[i].setDimensions(size,size);
                rects[i].setPosition(Random::getRange(0,800),Random::getRange(0,512));
            }
        }

        if(!reverse) {
            rects[i].y += speed;
            if(rects[i].y > 512) {
                int size = Random::getRange(2,5);
                rects[i].setDimensions(size,size);
                rects[i].setPosition(Random::getRange(0,800),Random::getRange(0,512));
            }
        }
       
    }
}

void Snow::render() {

    for(int i = 0;i<rects.size();i++) {
        al_draw_filled_rectangle(rects[i].x,rects[i].y,rects[i].x + rects[i].w,rects[i].y + rects[i].h,this->color);
    }
}