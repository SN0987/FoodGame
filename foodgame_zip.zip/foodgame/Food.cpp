#include <iostream>
#include <allegro5/allegro5.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>
#include "includes/Rectangle.hpp"
#include "includes/Trail.hpp"
#include "includes/Player.hpp"
#include "includes/Bullets.hpp"
#include "includes/Random.hpp"
#include "includes/Food.hpp"




ALLEGRO_COLOR Food::checkColors() {
    ALLEGRO_COLOR color;
    if(type == "pizza") {
        color = al_map_rgb(242, 151, 31);
      
    }

    if(type == "chicken") {
        color = al_map_rgb(133, 79, 9);
        
    }

    if(type == "eggs") {
        color = al_map_rgb(255,255,255);
        
    }   

    if(type == "taki") {
        color = al_map_rgb(9, 80, 232);
    }

    if(type == "cheeto") {
        color = al_map_rgb(232, 17, 9);
    }

    return color;
}


void Food::update(Bullets& bullets,bool& reverse) {
    rect.y += fallSpeed;

    if(reverse) {
        if(rect.y < 0) {
            rect.setPosition(Random::getRange(0,800),530);
            type = types[Random::getRange(0,4)];
          

        }

        for(int i = 0;i<bullets.bullets.size();i++) {
            if(rect.collide(bullets.getRects(i))) {
                rect.setPosition(Random::getRange(0,800),530);
                type = types[Random::getRange(0,4)];
       
            }
        }
        
    }

    if(!reverse) {
        if(rect.y >= 512) {
            rect.setPosition(Random::getRange(0,800),0);
            type = types[Random::getRange(0,4)];
        }

        for(int i = 0;i<bullets.bullets.size();i++) {
            if(rect.collide(bullets.getRects(i))) {
                rect.setPosition(Random::getRange(0,800),0);
                type = types[Random::getRange(0,4)];
            }
        }

       
    }
    



}

int Food::getFallSpeed() {
    return this->fallSpeed;

}

void Food::setFallSpeed(int fallSpeed) {
    this->fallSpeed = fallSpeed;
}

void Food::render(bool& reverse) {
    if(reverse) {
        if(type == "pizza") {
            al_draw_scaled_bitmap(bitmapRev,4*32,0,32,32,rect.x,rect.y,60,60,0);
        }

        if(type == "taki") {
            al_draw_scaled_bitmap(bitmapRev,3*32,0,32,32,rect.x,rect.y,60,60,0);
        }


        if(type == "cheeto") {
            al_draw_scaled_bitmap(bitmapRev,2*32,0,32,32,rect.x,rect.y,60,60,0);
        }


        if(type == "eggs") {
            al_draw_scaled_bitmap(bitmapRev,5*32,0,32,32,rect.x,rect.y,60,60,0);
        }

        if(type == "chicken") {
            al_draw_scaled_bitmap(bitmapRev,6*32,0,32,32,rect.x,rect.y,60,60,0);
        }
    }

    if(!reverse) {
        if(type == "pizza") {
            al_draw_scaled_bitmap(bitmap,4*32,0,32,32,rect.x,rect.y,60,60,0);
        }

        if(type == "taki") {
            al_draw_scaled_bitmap(bitmap,3*32,0,32,32,rect.x,rect.y,60,60,0);
        }


        if(type == "cheeto") {
            al_draw_scaled_bitmap(bitmap,2*32,0,32,32,rect.x,rect.y,60,60,0);
        }


        if(type == "eggs") {
            al_draw_scaled_bitmap(bitmap,5*32,0,32,32,rect.x,rect.y,60,60,0);
        }

        if(type == "chicken") {
            al_draw_scaled_bitmap(bitmap,6*32,0,32,32,rect.x,rect.y,60,60,0);
        }
    }  

}


Rectangle* Food::getRect() {
    return &this->rect;
}