#pragma once
#include <iostream>




class Rectangle {
    private:


    public:
        float w;
        float h;
        float x;
        float y;

        Rectangle(float x,float y,float w,float h) {
            this->w = w;
            this->h = h;
            this->x = x;
            this->y = y;
        }

        Rectangle() {
            
        }

        void setDimensions(float w,float h);

        void setPosition(float x,float y);


        bool collidePoint(float& cx,float& cy);


        bool collide(Rectangle rect);

};