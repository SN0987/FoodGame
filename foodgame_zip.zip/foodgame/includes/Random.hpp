#pragma once
#include <iostream>

namespace Random {
    int getRange(int min,int max);
}
