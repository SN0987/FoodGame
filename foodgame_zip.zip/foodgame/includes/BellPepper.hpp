#pragma once
#include <allegro5/allegro5.h>
#include <iostream>
#include <allegro5/allegro_image.h>
#include <vector>
#include "Bullets.hpp"
#include "Player.hpp"


class BellPepper {
    private:
        ALLEGRO_BITMAP* bitmap;


    public:
        int bellpeppers;
        BellPepper(std::vector<ALLEGRO_BITMAP*>& bitmaps) {
            bellpeppers = 3;
            bitmap = nullptr;
            bitmap = al_load_bitmap("assets/food_down.png");

            bitmaps.push_back(bitmap);

        }


        void update(Bullets& bullets,Player& player);


        void render();
};