#pragma once
#include <iostream>
#include <allegro5/allegro5.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_primitives.h>
#include <vector>



class Background {
    private:
        ALLEGRO_BITMAP* bitmap;
        
    public:
        Background(std::vector<ALLEGRO_BITMAP*>& images) {
            bitmap = nullptr;
            bitmap = al_load_bitmap("assets/bg.png");

            images.push_back(bitmap);
        }


        void render(bool& reverse);

};