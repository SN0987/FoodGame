#pragma once
#include <allegro5/allegro5.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include <iostream>
#include <vector>
#include "Rectangle.hpp"
#include "Random.hpp"


class Snow {
    private:
        std::vector<Rectangle> rects;
        ALLEGRO_COLOR color;
        int speed;
        

    public:
        Snow(int amount,int speed) {
           
            this->speed = speed;
            for(int i = 0;i<amount;i++) {
                int size = Random::getRange(2,5);
                Rectangle rect(Random::getRange(0,800),Random::getRange(0,512),size,size);
                rects.push_back(rect);
            }
        }

        void setColor(ALLEGRO_COLOR color);


        void update(bool& reverse);

        void render();

};