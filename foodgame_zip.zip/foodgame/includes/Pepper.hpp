#pragma once
#include <iostream>
#include <allegro5/allegro5.h>
#include <allegro5/allegro_image.h>
#include "Rectangle.hpp"
#include "Player.hpp"




class Pepper {
    private:
 
        ALLEGRO_BITMAP* bitmap;


    public:
        int peppers;
        Pepper(std::vector<ALLEGRO_BITMAP*> bitmaps) {
            peppers = 3;
            bitmap = nullptr;    
            bitmap = al_load_bitmap("assets/food_down.png");
            
            bitmaps.push_back(bitmap);
        }

        void update(Player& player);

        void render();
};