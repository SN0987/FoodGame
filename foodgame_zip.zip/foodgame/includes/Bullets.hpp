#pragma once
#include <allegro5/allegro5.h>
#include <allegro5/allegro_primitives.h>
#include <iostream>
#include <vector>
#include "Rectangle.hpp"
#include "Trail.hpp"


class Bullets {
    private:
      

        int speedY;

        ALLEGRO_COLOR color;
        Trail* trail;


    public:
        std::vector<Rectangle> bullets;
        
        Bullets(int speedY,ALLEGRO_COLOR color) {
            this->speedY = speedY;
            this->color = color;
            trail = new Trail(0,-speedY - 2,8,8,color);
        }

        void setColor(ALLEGRO_COLOR color);

        void add(int x,int y);

        void render();
        
        Rectangle getRects(int index);


        void setSpeedY(int speedY);

        void update();
};