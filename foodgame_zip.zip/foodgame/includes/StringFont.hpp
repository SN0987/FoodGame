#pragma once
#include <allegro5/allegro5.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <iostream>
#include <vector>


class StringFont  {
    private:
        int size,x,y;
        std::string text;
        ALLEGRO_FONT* font;
        ALLEGRO_COLOR color;
    public:
        StringFont(int x,int y,int size,std::vector<ALLEGRO_FONT*>& fonts)  {
            font = nullptr;
            this->x = x;
            this->size = size;
            this->y = y;
            font = al_load_ttf_font("fonts/font.ttf",this->size,0);
            fonts.push_back(font);
        }


        void setText(std::string text) ;

        void setColor(ALLEGRO_COLOR color);  

        void setSize(int size);

        void render();
};      