#pragma once
#include <allegro5/allegro5.h>
#include <allegro5/allegro_image.h>
#include <iostream>




class Animator {
    private:
        int frames;
        int time;

    public:
        Animator() {
            this->frames = 0;
            this->time = 0;

        }   


        void animate(int fps,int aOfFrames,ALLEGRO_BITMAP* bitmap,float x,float y,float width,float height);
};