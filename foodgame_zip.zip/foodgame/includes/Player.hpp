#pragma once
#include <iostream>
#include <allegro5/allegro5.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_primitives.h>
#include <vector>
#include "Rectangle.hpp"
#include "Animator.hpp"
#include "Trail.hpp"

class Player {
    private:
        ALLEGRO_BITMAP* cupiaRight;
        ALLEGRO_BITMAP* cupiaLeft;
        ALLEGRO_BITMAP* cupiaRevRight;
        ALLEGRO_BITMAP* cupiaRevLeft;

        Rectangle rect;
        Animator aOne;
        Animator aTwo;
        Animator aThree;
        Animator aFour;

        std::string aState;

        Trail* leftTrail;
        Trail* rightTrail;
        Trail* revRightTrail;
        Trail* revLeftTrail;
        
      


    public:
        int amountOfTimes,time,speed;
        bool change;
        int reverseTime;
        Player(int x,int y,std::vector<ALLEGRO_BITMAP*>& bitmaps) {
            aState = "idle";
            cupiaLeft = nullptr;
            cupiaRevLeft = nullptr;
            cupiaRevRight = nullptr;
            cupiaRight = nullptr;

            cupiaLeft = al_load_bitmap("assets/cupia_left.png");
            cupiaRight = al_load_bitmap("assets/cupia_right.png");
            cupiaRevLeft = al_load_bitmap("assets/cup_reverse_left.png");
            cupiaRevRight = al_load_bitmap("assets/cupia_reverse_right.png");

            bitmaps.push_back(cupiaLeft);
            bitmaps.push_back(cupiaRight);
            bitmaps.push_back(cupiaRevLeft);
            bitmaps.push_back(cupiaRevRight);

            rect.setDimensions(80,80);
            rect.setPosition(x,y);

            leftTrail = new Trail(5,0,10,5,al_map_rgb(0,130,0));
            rightTrail = new Trail(-5,0,10,5,al_map_rgb(0,130,0));

            revRightTrail = new Trail(-5,0,10,5,al_map_rgb(200,0,0));
            revLeftTrail = new Trail(5,0,10,5,al_map_rgb(200,0,0));
            speed = 10;
            amountOfTimes = 0;
            time = 0;
            reverseTime = 0;

        }


        void setPosition(int x,int y);

        void speedUp();

        void update(bool& reverse,ALLEGRO_KEYBOARD_STATE* ks);

        void render();

        Rectangle* getRect();
};