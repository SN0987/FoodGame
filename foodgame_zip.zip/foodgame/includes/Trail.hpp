#pragma once
#include <allegro5/allegro5.h>
#include <allegro5/allegro_primitives.h>
#include <iostream>
#include "Rectangle.hpp"
#include <vector>

class Trail {
    private:
        std::vector<Rectangle> rectlist;
        int velX,velY,w,h;
        ALLEGRO_COLOR color;
        int time;
        
        
    public:
        Trail(int velX,int velY,int w,int h,ALLEGRO_COLOR color) { 
            this->velX = velX;
            this->velY = velY;
            this->w = w;
            this->h = h;
            this->color = color;


        }

        void add(int x,int y);

        void setColor(ALLEGRO_COLOR color);

        void update();

        void setVelY(int velY);

        void setVelX(int velX);

        void render();
};