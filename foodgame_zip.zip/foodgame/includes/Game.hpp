#pragma once
#include <iostream>
#include <allegro5/allegro5.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_primitives.h>
#include <vector>
#include "Background.hpp"
#include "StringFont.hpp"
#include "Snow.hpp"
#include "Player.hpp"
#include "Pepper.hpp"
#include "BellPepper.hpp"
#include "Bullets.hpp"
#include "Food.hpp"

class Game {
    private:
        int width,height,fps;
        std::string state;
        ALLEGRO_DISPLAY* display;
        ALLEGRO_TIMER* fpsTimer;
        ALLEGRO_EVENT_QUEUE* queue;
        std::vector<ALLEGRO_TIMER*> timers;
        std::vector<ALLEGRO_BITMAP*> bitmaps;
        std::vector<ALLEGRO_FONT*> fonts;
        bool isDisplay;
        bool reverse;
        Background* bg;
        StringFont* titleText;
        ALLEGRO_KEYBOARD_STATE ks;
        ALLEGRO_MOUSE_STATE ms;
        StringFont* clickText;
        Snow* snowRed;
        Snow* snowGreen;
        ALLEGRO_TIMER* clickTimerOne;
        ALLEGRO_TIMER* clickTimerTwo;
        Player* player;
        ALLEGRO_TIMER* reverseTimerOne;
        ALLEGRO_TIMER* reverseTimerTwo;
        Pepper* pepper;
        BellPepper* bPepper;
        Bullets* bullets;
        unsigned long int gameTime;
        int spawnPepperTime;
        int spawnBellTime;
        int seconds;
        StringFont* timeText;
        StringFont* modeText;
        Food* foodOne;
        Food* foodTwo;
        Food* foodThree;
        






    public:
        Game(int width,int height,int fps) {
            this->width = width;
            this->height = height;
            this->fps = fps;
            this->state = "menu";

            load();

            loop();
        }
        
        void destroy();
        void registerTimers();
        void unregisterTimers();
        void destroyTimers();
        void destroyFonts();
        void destroyImages();
        void load();
        void init();
        void render();
        void update();
        void loop();
        void resetGame();
        void resetMenu();




    
};