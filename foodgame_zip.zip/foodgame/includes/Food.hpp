#pragma once
#include <iostream>
#include <allegro5/allegro5.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>
#include "Rectangle.hpp"
#include "Trail.hpp"
#include "Player.hpp"
#include "Bullets.hpp"
#include "Random.hpp"


class Food {
    private:
        std::string type;
        std::string types[5];
        
        ALLEGRO_BITMAP* bitmap;
        ALLEGRO_BITMAP* bitmapRev;
        int fallSpeed;
        Rectangle rect;

    public:
        
        Food(std::vector<ALLEGRO_BITMAP*>& bitmaps,int speed) {
            bitmap = nullptr;
            bitmapRev = nullptr;

            fallSpeed = speed;
            types[0] = "chicken";
            types[1] = "taki";
            types[2] = "cheeto";
            types[3] = "pizza";
            types[4] = "eggs";

            type = types[Random::getRange(0,4)];

            bitmap = al_load_bitmap("assets/food_down.png");
            bitmapRev = al_load_bitmap("assets/food_up.png");

            bitmaps.push_back(bitmap);
            bitmaps.push_back(bitmapRev);

        
            rect.setPosition(Random::getRange(0,800),0);
            rect.setDimensions(48,48);

        }

        ALLEGRO_COLOR checkColors();

        int getFallSpeed(); 

        void setFallSpeed(int fallSpeed);

        void update(Bullets& bullets,bool& reverse);


        void render(bool& reverse);

        Rectangle* getRect();
};