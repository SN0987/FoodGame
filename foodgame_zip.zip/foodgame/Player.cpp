
#include <iostream>
#include <allegro5/allegro5.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_primitives.h>
#include <vector>
#include "includes/Animator.hpp"
#include "includes/Rectangle.hpp"

#include "includes/Player.hpp"



void Player::setPosition(int x,int y) {
    rect.setPosition(x,y);
}

void Player::update(bool& reverse,ALLEGRO_KEYBOARD_STATE* ks) {
    if(!reverse) {
        if(al_key_down(ks,ALLEGRO_KEY_RIGHT) || al_key_down(ks,ALLEGRO_KEY_D)) {
            rect.x += speed;
            aState = "right";
            rightTrail->add(rect.x,rect.y + rect.h/2);
        } else if(al_key_down(ks,ALLEGRO_KEY_LEFT) || al_key_down(ks,ALLEGRO_KEY_A)) {
            rect.x -= speed;
            aState = "left";
            leftTrail->add(rect.x + rect.w,rect.y + rect.h/2);
        } else {
            aState = "idle";
        }
    }

    if(reverse) {
        if(al_key_down(ks,ALLEGRO_KEY_RIGHT) || al_key_down(ks,ALLEGRO_KEY_D)) {
            rect.x -= speed;
            aState = "rleft";
            revLeftTrail->add(rect.x + rect.w,rect.y + rect.h/2);

        } else if(al_key_down(ks,ALLEGRO_KEY_LEFT) || al_key_down(ks,ALLEGRO_KEY_A)) {
            rect.x += speed;
            aState = "rright";
            revRightTrail->add(rect.x,rect.y + rect.h/2);
        } else {
            aState = "ridle";
        }
    }


    if(rect.x <= 0) {
        rect.x = 0;
        if(reverse) {
            aState = "ridle";
        } else {
            aState = "idle";
        }
    } else if(rect.x >= 800 - 80) {
        rect.x = 800 - 80;
        if(reverse) {
            aState = "ridle";
        } else {
            aState = "idle";
        }
    }
    
    if(change == true) {
        time++;
        if(time >= (3*60)*amountOfTimes) {
            time = 0;
            speed = 11;
            change = false;
            amountOfTimes = 0;
            
        }
    }

    leftTrail->update();
    rightTrail->update();
    revRightTrail->update();
    revLeftTrail->update();

    reverseTime++;
}

void Player::render() {

    if(aState == "right") {
        aOne.animate(6,3,cupiaRight,rect.x,rect.y,rect.w,rect.h);
    }

    if(aState == "left") {
        aTwo.animate(6,3,cupiaLeft,rect.x,rect.y,rect.w,rect.h);
    }

    if(aState == "idle") {
        al_draw_scaled_bitmap(cupiaRight,0,0,32,32,rect.x,rect.y,rect.w,rect.h,0);
    }

    if(aState == "ridle") {
        al_draw_scaled_bitmap(cupiaRevRight,0,0,32,32,rect.x,rect.y,rect.w,rect.h,0);
    }

    if(aState == "rright") {
        aThree.animate(6,3,cupiaRevRight,rect.x,rect.y,rect.w,rect.h);
    }

    if(aState == "rleft") {
        aFour.animate(6,3,cupiaRevLeft,rect.x,rect.y,rect.w,rect.h);
    }

    leftTrail->render();
    rightTrail->render();
    revLeftTrail->render();
    revRightTrail->render();
}


Rectangle* Player::getRect() {
    return &this->rect;
}

void Player::speedUp() {
    speed *= 3;
    amountOfTimes++;
    change = true;
    printf("%d\n",speed);

}