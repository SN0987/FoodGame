#include <iostream>
#include <allegro5/allegro5.h>
#include <allegro5/allegro_image.h>
#include "includes/Rectangle.hpp"
#include "includes/Player.hpp"


#include "includes/Pepper.hpp"


void Pepper::update(Player& player) {
    if(peppers > 0) {
        player.amountOfTimes++;
        player.speed *= 2;
        if(player.change == false) {
            player.change = true;
        }
        peppers -= 1;
        
        
    }
}


void Pepper::render() {
    if(peppers == 3) {
        al_draw_scaled_bitmap(bitmap,0,0,32,32,0,512-42,32,32,0);
        al_draw_scaled_bitmap(bitmap,0,0,32,32,42,512-42,32,32,0);
        al_draw_scaled_bitmap(bitmap,0,0,32,32,84,512-42,32,32,0);
    }

    if(peppers == 2) {
        al_draw_scaled_bitmap(bitmap,0,0,32,32,0,512-42,32,32,0);
        al_draw_scaled_bitmap(bitmap,0,0,32,32,42,512-42,32,32,0);
    }

    if(peppers == 1) {
        al_draw_scaled_bitmap(bitmap,0,0,32,32,0,512-42,32,32,0);
    }
}