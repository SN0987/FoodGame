#include <allegro5/allegro5.h>
#include <iostream>
#include <allegro5/allegro_image.h>
#include <vector>
#include "includes/Rectangle.hpp"


#include "includes/Bullets.hpp"


void Bullets::add(int x,int y) {
    bullets.push_back(Rectangle(x,y,10,20));
}

void Bullets::setSpeedY(int speedY) {
    this->speedY = speedY;
    trail->setVelY(-this->speedY - 2);

}

void Bullets::setColor(ALLEGRO_COLOR color) {
    this->color = color;
    trail->setColor(color);
    
}

void Bullets::update() {
    for(int i = 0;i<bullets.size();i++) {
        bullets[i].y += this->speedY;

        if(bullets[i].y <= 0) {
            bullets.erase(bullets.begin() + i);
        }

        if(bullets[i].y >= 512) {
            bullets.erase(bullets.begin() + i);
        }

        trail->add(bullets[i].x + 3,bullets[i].y + bullets[i].w);
    }
    

    trail->update();
}

void Bullets::render() {
    for(int i = 0;i<bullets.size();i++) {
        al_draw_filled_rectangle(bullets[i].x,bullets[i].y,bullets[i].x + bullets[i].w,bullets[i].y + bullets[i].h,color);
    }

    trail->render();
}

Rectangle Bullets::getRects(int index) {
    return this->bullets[index];
}