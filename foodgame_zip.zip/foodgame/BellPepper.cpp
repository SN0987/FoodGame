#include <allegro5/allegro5.h>
#include <iostream>
#include <allegro5/allegro_image.h>
#include <vector>
#include "includes/BellPepper.hpp" 
#include "includes/Bullets.hpp"
#include "includes/Player.hpp"



void BellPepper::update(Bullets& bullets,Player& player) {
    if(bellpeppers > 0) {
        bellpeppers -= 1;
        bullets.add(player.getRect()->x+40,player.getRect()->y);
    }
}

void BellPepper::render() {
    if(bellpeppers == 3) {
        al_draw_scaled_bitmap(bitmap,1*32,0,32,32,800-42,512-42,32,32,0);
        al_draw_scaled_bitmap(bitmap,1*32,0,32,32,800-84,512-42,32,32,0);
        al_draw_scaled_bitmap(bitmap,1*32,0,32,32,800-126,512-42,32,32,0);
    }   

    if(bellpeppers == 2) {
        al_draw_scaled_bitmap(bitmap,1*32,0,32,32,800-42,512-42,32,32,0);
        al_draw_scaled_bitmap(bitmap,1*32,0,32,32,800-84,512-42,32,32,0);
    }

    if(bellpeppers == 1) {
        al_draw_scaled_bitmap(bitmap,1*32,0,32,32,800-42,512-42,32,32,0);
    }
}