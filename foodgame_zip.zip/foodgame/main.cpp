#include <iostream>
#include <allegro5/allegro5.h>
#include "includes/Game.hpp"
#include <cstdlib>
#include <ctime>
#include <random>



int main() {
    srand(time(NULL));
    Game game(800,512,60);
    
    return 0;
}