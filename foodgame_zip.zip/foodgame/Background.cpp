#include <iostream>
#include <allegro5/allegro5.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_primitives.h>
#include <vector>


#include "includes/Background.hpp"




void Background::render(bool& reverse) {

    if(!reverse) {
        al_draw_scaled_bitmap(bitmap,0,0,32,32,0,0,800,512,0);
    } else if(reverse) {
        al_draw_scaled_bitmap(bitmap,32,0,32,32,0,0,800,512,0);
    }
    
}