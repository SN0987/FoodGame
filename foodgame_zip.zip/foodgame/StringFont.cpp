#include <allegro5/allegro5.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <iostream>
#include <vector>
#include "includes/StringFont.hpp"

void StringFont::setText(std::string text) {
    this->text = text;
}

void StringFont::setColor(ALLEGRO_COLOR color) {
    this->color = color;

} 

void StringFont::setSize(int size) {
    this->size = size;
}


void StringFont::render() {
    al_draw_text(font,this->color,this->x,this->y,0,this->text.c_str());
}